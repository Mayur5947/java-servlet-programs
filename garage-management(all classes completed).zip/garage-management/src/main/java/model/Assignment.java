package model;

public class Assignment {
    private int assignment_id;
    private int request_id;
    private int technician_id;
    private String date;
    private String status;

    public int getAssignment_id() {
        return assignment_id;
    }

    public void setAssignment_id(int assignment_id) {
        this.assignment_id = assignment_id;
    }

    public int getRequest_id() {
        return request_id;
    }

    public void setRequest_id(int request_id) {
        this.request_id = request_id;
    }

    public int getTechnician_id() {
        return technician_id;
    }

    public void setTechnician_id(int technician_id) {
        this.technician_id = technician_id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Assignment{" +
                "assignment_id=" + assignment_id +
                ", request_id=" + request_id +
                ", technician_id=" + technician_id +
                ", date='" + date + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}
