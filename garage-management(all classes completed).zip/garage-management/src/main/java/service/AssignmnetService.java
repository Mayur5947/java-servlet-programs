package service;

import java.util.List;

import model.Assignment;
import model.Bike;
import repository.AssignmentRepository;
import repository.BikeRepository;

public class AssignmnetService {

	AssignmentRepository assignmentRepository = new AssignmentRepository();

	public void getAssignment(int request_id, int technician_id, Assignment assignment, int part_id) throws Exception {
		assignmentRepository.addAssignment(request_id, technician_id, assignment, part_id);
	}

	public Assignment getAssignment(int assignment_id) throws Exception {
		return assignmentRepository.getAssignment(assignment_id);
	}
	
	public List<Assignment> getAllAssignment() throws Exception {
		return assignmentRepository.getAllAssignment();
	}
	
	public void updateAssignment(Assignment assignment) throws Exception {
		assignmentRepository.updateAssignment(assignment);
	}
}

